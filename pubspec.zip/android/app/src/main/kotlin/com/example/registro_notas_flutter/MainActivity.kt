package com.example.registro_notas_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
